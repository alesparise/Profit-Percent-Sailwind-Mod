﻿using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;
//poorly written by pr0skynesis (discord username)

namespace ProfitPercent
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class ProfitPercentMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.profitpercent";
        public const string pluginName = "Profit Percent";
        public const string pluginVersion = "1.0.2";

        public void Awake()
        {
            //Logger.LogInfo("Profit Percent is loaded!");

            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(EconomyUI), "GetProfitString");
            MethodInfo patch = AccessTools.Method(typeof(ProfitPercentPatches), "GetProfitString_Patch");

            harmony.Patch(original, new HarmonyMethod(patch)); //patch applied
        }
    }
    public class ProfitPercentPatches   //contains the patch and two methods necessary for it to work
    {
        [HarmonyPrefix] //patch happens before original
        public static bool GetProfitString_Patch(int portIndex, int goodIndex, ref string __result, IslandMarket ___currentIsland, Currency ___currentPlayerCurrency)
        {   //the patch as a whole replaces the original method entirely. If that changes this will probably break.

            //emulate the GetSellprice and GetBuyPrice methods from EconomyUI (they are private)
            int sellp = SellPrice(portIndex, goodIndex, ___currentIsland, ___currentPlayerCurrency);
            int buyp = BuyPrice(___currentIsland.GetPortIndex(), goodIndex, ___currentIsland, ___currentPlayerCurrency);

            if (buyp == 0)      //if this is true the good is not sold at the current location
            {
                //Debug.Log("Selected good is not for sale at current location");
                __result = "<color=#CC7F00>-</color>";
                return false;   //by returning false we skip the original method entirely
            }
            else
            {
                float profitpercent = Mathf.Round((sellp - buyp) / (float)buyp * 100);
                //Debug.Log("Profit percentage is: " + profitpercent + " %");
                if (sellp > buyp)   //this means profit, color is green
                {
                    __result = $"<color=#113905><size=52%>{sellp - buyp} <size=42%>({profitpercent}%)</size></size></color>";
                }
                else if (sellp < buyp)  //this means loss, color is red
                {
                    __result = $"<color=#7C0000><size=52%>{sellp - buyp} <size=42%>({profitpercent}%)</size></size></color>";
                }
                else if (sellp == buyp) //this means no loss and no profit, color is yellowish
                {
                    __result = $"<color=#CC7F00><size=52%>{sellp - buyp} <size=42%>({profitpercent}%)</size></size></color>";
                }
                return false;   //by returning false we skip the original method entirely
            }
        }
        private static int SellPrice(int portIndex, int goodIndex, IslandMarket currentIsland, Currency currentPlayerCurrency)
        {
            //Debug.Log("SellPrice has done something");
            int num = currentIsland.knownPrices[portIndex].sellPrices[goodIndex];
            bool withConversionFee = Port.ports[portIndex].region != (PortRegion)currentPlayerCurrency;
            int sellPrice = CurrencyMarket.instance.GetSellPriceInCurrency(currentPlayerCurrency, (float)num, withConversionFee);
            //Debug.Log("sellPrice is: " + sellPrice);
            return sellPrice;
        }
        private static int BuyPrice(int portIndex, int goodIndex, IslandMarket currentIsland, Currency currentPlayerCurrency)
        {
            //Debug.Log("buyPrice has done something");
            int num = currentIsland.knownPrices[portIndex].buyPrices[goodIndex];
            bool withConversionFee = Port.ports[portIndex].region != (PortRegion)currentPlayerCurrency;
            int buyPrice = CurrencyMarket.instance.GetBuyPriceInCurrency(currentPlayerCurrency, (float)num, withConversionFee);
            //Debug.Log("buyPrice is: " + buyPrice);
            return buyPrice;
        }
    }

}
